<html>
	<body>
		<h1 style="color:MediumSeaGreen;">Welcome to Vetpital</h1>
		<h3>Would you like to</h3>
		<form action="Search.php" method="get">
			<p><input type="submit" value="Search"/></p>
		</form>
		<br>
		<br>
		<br>
		<form action="https://www.instagram.com/p/Bq1XlcjAvr3/?utm_source=ig_share_sheet&igshid=143zsnmqhmbij" method="get">
			<p>See a video that shows the love that our clients have for us:</p>
			<p><input type="submit" value="Link to the video"/></p>
		</form>
	</body>
</html>